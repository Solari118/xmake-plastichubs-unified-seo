# Registry Audit

- OK: `True`
- Package: `b2b-machining-image-generator`
- Version: `0.1.0`
- Maturity: `production`
- Owner: `Lostk`
- License: `Proprietary`
- Package SHA256: `b02a2e75d53421017ef2df9b55a76ca55c1b005f606ca794e83a69acd15fb3e2`
- Archive SHA256: `n/a`
- Install simulated: `False`

## Compatibility

| Target | Status |
| --- | --- |
| `openai` | `pass` |
| `generic` | `pass` |

## Failures

- None

## Warnings

- None

## Artifacts

- index: `C:\Users\Lostk\Documents\B2B机加工生图\b2b-machining-image-generator\registry\index.json`
- package: `C:\Users\Lostk\Documents\B2B机加工生图\b2b-machining-image-generator\registry\packages\b2b-machining-image-generator.json`
- json: `C:\Users\Lostk\Documents\B2B机加工生图\b2b-machining-image-generator\reports\registry_audit.json`
- markdown: `C:\Users\Lostk\Documents\B2B机加工生图\b2b-machining-image-generator\reports\registry_audit.md`
